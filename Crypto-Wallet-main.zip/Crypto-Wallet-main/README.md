# Crypto-Wallet

Crypto Currency app display crypto currencies prices using [Coingecko API](https://www.coingecko.com/tr/api)

# Key features
 
 * ✔ Mvvm
 * ✔ Navigation Component
 * ✔ Retrofit
 * ✔ Okhttp!
 

![WhatsApp Video 2021-12-07 at 13 50 08](https://user-images.githubusercontent.com/37241744/145016401-84381591-06be-471b-991a-c0f9b9b469b0.gif)
