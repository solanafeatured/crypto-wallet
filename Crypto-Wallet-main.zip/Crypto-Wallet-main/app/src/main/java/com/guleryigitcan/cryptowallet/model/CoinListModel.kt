package com.guleryigitcan.cryptowallet.model

 class CoinListModel :ArrayList<CoinModel>()

